﻿using System;
using System.Collections.Generic;
using System.Windows.Threading;


namespace ChaKeyz
{
    public class Chan
    {

        public String id;
        public String name;
        public String history;
        public Boolean newMessages;
        public DateTime lastMessage;
        public Boolean isPrivate;
        public List<Peer> peers;
        public Boolean opened;

        public Boolean NewMessages { get { return newMessages; } }
        public String Name { get { return name; } }

        public Chan(String name, String id = "")
        {
            this.name = name;
            if (id == "") id = Self.MD5ThisShit(name);
            else this.id = id;

            history = "";
            isPrivate = false;
            newMessages = false;
            opened = false;
            lastMessage = DateTime.Now;
            peers = new List<Peer>();
        }




        public void addChan(Boolean opened = false)
        {
            this.opened = opened;
            Self.chans.Add(this);
        }


        public void delChan()
        {
            if (opened) Leave();
        }



        public void Show()
        {
            opened = true;
            Self.win.RefreshChans();
        }

        public void Hide()
        {
            opened = false;
            Self.win.RefreshChans();
        }


        public void Join()
        {
            Show();
            //sendtoall 'cause you probably don't know who is in there,
            //so sendTo can't select Peers to send that Join
            Self.win.SendToAll(new DataChan { to = id, option = ChanOption.Join });
        }

        public void Leave()
        {
            Hide();
            Self.win.SendTo(new DataChan { option = ChanOption.Leave }, id);
        }

        public override string ToString()
        {
            return name;
        }

        public ChanItem GetItem()
        {
            return new ChanItem { id = id, name = name, opened = opened };
        }
    }
}