﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace ChaKeyz
{
    public class Peer
    {


         public String id;
        public Boolean isAlive;
        public IPEndPoint iep;

        Boolean haveAlreadyCrashedOnceAndTriedToFlush = false;

        NetworkStream ns;
        ManualResetEvent doneEvent;


        public static IPEndPoint IPEndPointFromString(String endPoint)
        {
            String[] tab = endPoint.Split(':');
            IPAddress ip;
            int port;

            if (!IPAddress.TryParse(tab[0], out ip)) ip = IPAddress.Parse("0.0.0.0");
            if (tab.Length == 1 || !Int32.TryParse(tab[1], out port)) port = 0;

            return new IPEndPoint(ip, port);
        }

        public void setDoneEvent(ManualResetEvent mre)
        {
            this.doneEvent = mre;
        }

        public String pseudo;
        public Boolean isIgnored;
        public Boolean connected;

        RSA rsa = new RSA(1024);
        AES aes = new AES();


        public Peer(TcpClient tc)
        {
            ns = tc.GetStream();

            iep = IPEndPointFromString(tc.Client.RemoteEndPoint.ToString());
            isAlive = true;
            connected = true;
        }


        public Peer()
        {
            connected = false;
        }


        public void SendData(Data data)
        {
            data.from = Self.id;

            if (data.type == DataType.Message)
            {
                DataMessage dm = (DataMessage)data;
                dm.msg = aes.EncryptToString(dm.msg, aes.Key, aes.IV);

                data = dm;
            }
            else if (data.type == DataType.File)
            {
                DataFile df = (DataFile)data;
                df.data = aes.EncryptToBytes(df.data, aes.Key, aes.IV);

                data = df;
            }
            else if (data.type == DataType.Voice) { }
            

            try
            {
                Self.bf.Serialize(ns, data);
                //Self.win.WriteNotice("sent : " + data.type.ToString());
                haveAlreadyCrashedOnceAndTriedToFlush = false;
            }
            catch (Exception e)
            {
                Self.win.WriteNotice("sent failed : " + data.type.ToString() + " " + e.Message);

                if (!haveAlreadyCrashedOnceAndTriedToFlush)
                {
                    ns.Flush();
                    haveAlreadyCrashedOnceAndTriedToFlush = true;
                }
                else
                    Kill();
            }
        }


        public void ReceiveData()
        {
            while (isAlive)
            {
                try
                {
                    Object o = Self.bf.Deserialize(ns);
                    if (o is Data) HandleData((Data)o);
                    //else bullshit detected

                    haveAlreadyCrashedOnceAndTriedToFlush = false;
                }
                catch (Exception e)
                {
                    Self.win.WriteNotice("received failed : " + e.Message);

                    if (!haveAlreadyCrashedOnceAndTriedToFlush)
                    {
                        ns.Flush();
                        haveAlreadyCrashedOnceAndTriedToFlush = true;
                    }
                    else
                        Kill();
                }
                
            }
        }

        public void SendHandShake()
        {
            SendData(new DataHandshake { id = Self.id, pseudo = Self.pseudo });
            SendData(new DataKey { rsaPublicKey = rsa.publickey, step = 1 });

            SendData(new DataSync { chans = Self.win.GetChansItem(), peers = Self.win.GetPeersItem()});
        }

        public void HandleData(Data data)
        {

            if (data.type == DataType.Announce)
            {
                DataAnnounce d = (DataAnnounce)data;

                if (d.isPeer)
                {
                    //Self.win.Connect(d.iep);
                }


            }
            else if (data.type == DataType.Handshake)
            {
                DataHandshake d = (DataHandshake)data;

                id = d.id;
                pseudo = GetUniquePseudo(d.pseudo);

                //add peer to main chan
                Self.win.GetChanById(Guid.Empty.ToString()).peers.Add(this);
                Self.win.RefreshPeers();
                Self.win.WriteNotice("New peer : " + pseudo, "", MainWindow.MessageType.Main);


            }
            else if (data.type == DataType.Sync)
            {
                DataSync ds = (DataSync)data;

                if (ds.chans != null)
                {
                    for (int i = 0; i < ds.chans.Length; i++)
                    {
                        Chan c = Self.win.GetChanById(ds.chans[i].id);
                        if (c == null)
                        {
                            c = new Chan(ds.chans[i].name, ds.chans[i].id);
                            if (ds.chans[i].opened) c.peers.Add(this);
                            c.addChan();
                        }
                        else
                        {
                            if (!c.peers.Contains(this))
                            {
                                if (ds.chans[i].opened) c.peers.Add(this);
                            }
                        }
                    }
                }

                if (ds.peers != null)
                {
                    for (int i = 0; i < ds.peers.Length; i++)
                    {
                        Peer p = Self.win.GetPeerById(ds.peers[i].id);
                        if (p == null)
                        {
                            if (!Self.win.IsLocalAddress(ds.peers[i].iep.Address))
                                Self.win.Connect(ds.peers[i].iep);
                        }
                    }
                }


                Self.win.RefreshPeers();

            }
            else if (data.type == DataType.Key)
            {
                DataKey d = (DataKey)data;

                if (d.step == 1)
                {
                    rsa.publickey = d.rsaPublicKey;

                    SendData(new DataKey { aesKey = rsa.Encrypt(aes.Key), IV = rsa.Encrypt(aes.IV), step = 2 });
                }
                else if (d.step == 2)
                {
                    if (Self.id.CompareTo(id) > 0) // =/
                    {
                        aes.Key = rsa.DecryptToBytes(d.aesKey);
                        aes.IV = rsa.DecryptToBytes(d.IV);
                    }
                }


            }
            else if (data.type == DataType.Message)
            {
                DataMessage dm = (DataMessage)data;

                if (Self.win.GetChanById(dm.to).peers.Contains(this))
                {
                    dm.msg = aes.DecryptToString(dm.msg, aes.Key, aes.IV);
                    Self.win.WriteMessage(pseudo, dm.msg, dm.to);
                }


            }
            else if (data.type == DataType.File)
            {
                DataFile df = (DataFile)data;
                int idxFile = Self.win.GetFileIndexByHash(df.fileinfo.hash);

                if (idxFile == -1)
                {
                    df.fileinfo.etat = FileStatus.Receive | FileStatus.Waiting;
                    Self.files.Add(df.fileinfo);
                    idxFile = Self.files.Count - 1;
                }

                sFile f = Self.files[idxFile];


                if (df.fileinfo.etat.HasFlag(FileStatus.Waiting))
                {
                    Self.win.WriteNotice(pseudo + " sending " + f.name + " (" + f.StringSize() + ")", df.to, MainWindow.MessageType.Current);
                    Self.win.RefreshFiles();

                }
                else if (df.fileinfo.etat.HasFlag(FileStatus.InProgress) && (f.etat.HasFlag(FileStatus.Accepted) ||f.etat.HasFlag(FileStatus.Accepted)))
                {
                    Self.files[idxFile].etat = FileStatus.InProgress | FileStatus.Receive;
                    df.data = aes.DecryptToBytes(df.data, aes.Key, aes.IV);
                    Self.win.RefreshFiles();
                    ReceiveFile(df);

                }
                else if (df.fileinfo.etat.HasFlag(FileStatus.Finished) && f.etat.HasFlag(FileStatus.InProgress))
                {
                    Self.files[idxFile].etat = FileStatus.Finished | FileStatus.Receive;
                    Self.win.RefreshFiles();

                    if (f.hash == sFile.Hash(Self.incomingFolder + f.name))
                        Self.win.WriteNotice(f.name + " received", df.to, MainWindow.MessageType.Current);
                    else
                        Self.win.WriteNotice(f.name + " received (errors)", df.to, MainWindow.MessageType.Current);

                }
                //just checkin if the peer accepting/requesting file is in a chan "allowed" to get it
                else if (df.fileinfo.etat.HasFlag(FileStatus.Accepted) && Self.win.GetChanById(f.to).peers.Contains(this))
                {
                    Self.files[idxFile].etat = FileStatus.InProgress | FileStatus.Send;
                    Self.win.RefreshFiles();
                    SendFile(f);
                    Self.win.WriteNotice(f.name + " sent " + pseudo, df.to, MainWindow.MessageType.Current);

                }
                else if (df.fileinfo.etat.HasFlag(FileStatus.Canceled) && f.etat.HasFlag(FileStatus.Waiting))
                {
                    Self.files[idxFile].etat = FileStatus.Canceled | FileStatus.Send;
                    Self.win.RefreshFiles();
                    Self.win.WriteNotice(pseudo + " canceled " + f.name, df.to, MainWindow.MessageType.Current);

                }


            }
            else if (data.type == DataType.Voice)
            {
                if (Self.currentChannel == data.to)
                {
                    DataVoice dv = (DataVoice)data;
                    //dv.buffer = aes.DecryptToBytes(dv.buffer);
                    Self.snd.Play(dv.buffer);
                }


            }
            else if (data.type == DataType.Disconnect)
            {
                Self.win.WriteNotice(pseudo + " disconnected", "", MainWindow.MessageType.Main);
                Kill();


            }
            else if (data.type == DataType.ChangeNick)
            {
                DataChangeNick dcn = (DataChangeNick)data;

                Self.win.WriteNotice(pseudo + " is now known as " + dcn.newPseudo, "", MainWindow.MessageType.Main);

                pseudo = dcn.newPseudo;
                Self.win.RefreshPeers();


            }
            else if (data.type == DataType.Chan)
            {
                DataChan dc = (DataChan)data;

                if (dc.option.HasFlag(ChanOption.Join))
                {
                    Chan c = Self.win.GetChanById(dc.to);

                    if (!c.peers.Contains(this))
                    {
                        if (!c.isPrivate)
                        {
                            c.peers.Add(this);
                            Self.win.RefreshPeers();
                            Self.win.WriteNotice(pseudo + " joined " + c.name, c.id, MainWindow.MessageType.Channel);

                            //say hi to the new guy
                            SendData(new DataChan { to = c.id, option = ChanOption.Join });
                        }
                    }


                }
                else if (dc.option.HasFlag(ChanOption.Leave))
                {
                    Chan c = Self.win.GetChanById(dc.to);
                    c.peers.Remove(this);
                    Self.win.RefreshPeers();
                    Self.win.WriteNotice(pseudo + " leaved " + c.name, c.id, MainWindow.MessageType.Channel);

                }
                else if (dc.option.HasFlag(ChanOption.Create))
                {
                    if (Self.win.GetChanById(dc.to) == null)
                    {
                        if (dc.option.HasFlag(ChanOption.Private))
                        {
                            Chan c = new Chan(pseudo, dc.to);
                            c.peers.Add(this);
                            c.isPrivate = true;
                            c.addChan(true);
                            c.Show();
                        }
                        else
                        {
                            Chan c = new Chan(dc.name, dc.to);
                            c.peers.Add(this);
                        }
                    }
                }
            }
        }



        public void SendFile(sFile sfile)
        {
            sfile.etat = FileStatus.InProgress;

            Int64 bytesRead = 0;
            Int64 buffersize = Self.buffersize;

            FileStream fs = new FileStream(Self.incomingFolder + sfile.name, FileMode.Open);
            if (fs.Length < buffersize) buffersize = fs.Length;

            Byte[] buffer;

            while (bytesRead < fs.Length)
            {
                if (buffersize > fs.Length - bytesRead) buffersize = fs.Length - bytesRead;
                buffer = new Byte[buffersize];
                
                int x = fs.Read(buffer, 0, (int)buffersize);
                SendData(new DataFile { fileinfo = sfile, data = buffer, position = bytesRead });
                bytesRead += x;
            }

            fs.Close();

            sfile.etat = FileStatus.Finished;
            Self.win.RefreshFiles();
            SendData(new DataFile { fileinfo = sfile });
        }



        public void ReceiveFile(DataFile f)
        {
            FileStream fs = new FileStream(Self.incomingFolder + f.fileinfo.name, FileMode.OpenOrCreate);
            fs.Position = f.position;
            fs.Write(f.data, 0, f.data.Length);
            fs.Close();
        }


        



        public static String GetUniquePseudo(String pseudo)
        {
            while (Self.win.GetPeerByPseudo(pseudo) != null)
            {
                pseudo += "_";
            } 

            return pseudo;
        }



        public void Kill()
        {
            isAlive = false;

            Self.peers.Remove(this);
            foreach (Chan c in Self.chans) c.peers.Remove(this);
            Self.win.RefreshPeers();

            if (connected)
            {
                ns.Close();
                doneEvent.Set();
            }
        }

        public override string ToString()
        {
            return pseudo;
        }


        public PeerItem GetItem()
        {
            return new PeerItem { id = id, pseudo = pseudo, iep = iep };
        }
    }
}
