﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;


namespace ChaKeyz
{
    public static class Self
    {
        //default values
        public static String pseudo = "Anon";
        public static Int32 tcpPort = 1337;
        public static Int32 udpPort = 1338;
        public static Int32 nodePort = 1339;
        public static Int64 buffersize = 1000000;
        public static String incomingFolder = AppDomain.CurrentDomain.BaseDirectory + "incoming\\";
        public static Boolean activeShare = true;

        public static String id;
        public static String currentChannel;

        public static List<Peer> peers = new List<Peer>();
        public static List<Chan> chans = new List<Chan>();
        public static List<sFile> files = new List<sFile>();

        public static BinaryFormatter bf;
        public static Sound snd;
        public static MainWindow win;

        /*
        public static Theme defaultTheme = new Theme { name = "default", backcolor = Color.Black, fontcolor = Color.White, font = new Font("Verdana", 12), size = new Size(680, 340) };
        public static Theme currentTheme;
        */

        [Flags]
        public enum MessageType { Global = 1, Main = 2, Channel = 4, Current = 8, Notice = 16, Mention = 32, Message = 64 };


        public static void Init()
        {
            id = GetId();
            bf = new BinaryFormatter();

            LoadConfig();
            
            snd = new Sound();
            snd.Init();

            Self.win.tc_chans.ItemsSource = Self.chans;
            Self.win.lb_files.ItemsSource = Self.files;
            Self.win.lb_peers.ItemsSource = Self.peers;


            Chan c = new Chan("Main", Guid.Empty.ToString());
            c.addChan(true);
            c.Show();
            currentChannel = c.id;
        }


        public static String GetId()
        {
            return Guid.NewGuid().ToString();
        }

        public static String MD5ThisShit(String txt)
        {
            MD5 md5 = MD5.Create();
            Byte[] b = md5.ComputeHash(UTF8Encoding.ASCII.GetBytes(txt));
            return BitConverter.ToString(b).Replace("-", "");
        }


        public static void LoadConfig()
        {
            int tcpPort, udpPort;
            long buffersize;
            String pseudo, incomingFolder;

            if (int.TryParse(ConfigurationManager.AppSettings.Get("tcpPort"), out tcpPort)) Self.tcpPort = tcpPort;
            if (int.TryParse(ConfigurationManager.AppSettings.Get("udpPort"), out udpPort)) Self.udpPort = udpPort;
            if (long.TryParse(ConfigurationManager.AppSettings.Get("buffer"), out buffersize)) Self.buffersize = buffersize;

            pseudo = ConfigurationManager.AppSettings.Get("pseudo");
            if (!String.IsNullOrWhiteSpace(pseudo)) Self.pseudo = pseudo;

            incomingFolder = ConfigurationManager.AppSettings.Get("incomingFolder");
            if (System.IO.Directory.Exists(incomingFolder)) Self.incomingFolder = incomingFolder;

            //String theme = ConfigurationManager.AppSettings.Get("theme");
        }
    }
}

