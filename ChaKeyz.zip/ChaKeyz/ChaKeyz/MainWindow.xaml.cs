﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Linq;


namespace ChaKeyz
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        Thread t_listenerTCP, t_listenerUDP;
        Boolean listeningTCP = false, listeningUDP = false;

        List<ManualResetEvent> doneEvents = new List<ManualResetEvent>();


        [Flags]
        public enum MessageType { Global = 1, Main = 2, Channel = 4, Current = 8, Notice = 16, Message = 32, Voice = 64 };

        public MainWindow()
        {
            InitializeComponent();

            Self.win = this;
            Self.Init();

            t_listenerTCP = new Thread(new ThreadStart(ListenTCP));
            t_listenerUDP = new Thread(new ThreadStart(ListenUDP));
            
            t_listenerTCP.Start();
            t_listenerUDP.Start();

            ToggleFiles();
            tb_enter.Focus();

            //ConnectUDP();
            
            //connect to local node
            /*
            t_listenerNode = new Thread(new ThreadStart(ListenNode));
            t_listenerNode.Start();
            
            Connect(new IPEndPoint(IPAddress.Loopback, Self.nodePort), false);
            */

            //theme(Colors.Bisque, Colors.Azure, "Verdana");
        }

        

        /// <summary>
        /// Set theme
        /// </summary>
        /// <param name="bgcolor">Background Color</param>
        /// <param name="fgcolor">Foreground Color</param>
        /// <param name="fontFamily">Font Family</param>
        public void theme(Color bgcolor, Color fgcolor, String fontFamily)
        {
            this.Background = tb_display.Background = tb_enter.Background = lb_peers.Background = lb_files.Background = tc_chans.Background = new SolidColorBrush(bgcolor);
            this.Foreground = tb_display.Foreground = tb_enter.Foreground = lb_peers.Foreground = lb_files.Foreground = tc_chans.Foreground = new SolidColorBrush(fgcolor);

            this.FontFamily = new FontFamily(fontFamily);
        }



        #region network

        /// <summary>
        /// Listen to new peers
        /// </summary>
        void ListenTCP()
        {
            TcpListener tl = new TcpListener(new IPEndPoint(IPAddress.Any, Self.tcpPort));
            try
            {
                tl.Start();
                listeningTCP = true;
                WriteNotice("listening : " + tl.LocalEndpoint.ToString());
            }
            catch (Exception e)
            {
                WriteNotice("listening failed : " + e.Message);
            }


            while (listeningTCP)
            {
                if (tl.Pending())
                {
                    TcpClient tc = tl.EndAcceptTcpClient(tl.BeginAcceptTcpClient(delegate { }, new Object()));
                    Peer p = addPeer(tc);
                    p.SendHandShake();
                }
                
                Thread.Sleep(200);
            }

            tl.Stop();
            t_listenerTCP.Abort();
        }


        /// <summary>
        /// UDP Listener for broadcast messages. When a message is received, we connect to the sender
        /// </summary>
        void ListenUDP()
        {
            Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            EndPoint ep = (EndPoint)new IPEndPoint(IPAddress.Any, Self.udpPort);

            try
            {
                sock.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, 1);
                sock.Bind(ep);
                listeningUDP = true;
            }
            catch (Exception e)
            {
                WriteNotice(e.Message);
            }


            while (listeningUDP)
            {
                Byte[] data = new Byte[8];
                int recv = sock.EndReceiveFrom(sock.BeginReceiveFrom(data, 0, data.Length, SocketFlags.None, ref ep, delegate { }, new Object()), ref ep);

                if (recv > 0)
                {
                    IPEndPoint iep = Peer.IPEndPointFromString(ep.ToString());
                    iep.Port = BitConverter.ToUInt16(data, 0);

                    if (!IsLocalAddress(iep.Address) || iep.Port != Self.tcpPort)
                        Connect(iep);
                }
            }

            sock.Close();
            t_listenerUDP.Abort();
        }


        Peer addPeer(TcpClient tc)
        {
            ManualResetEvent mre = new ManualResetEvent(false);

            Peer p = new Peer(tc);
            p.setDoneEvent(mre);
            doneEvents.Add(mre);

            Self.peers.Add(p);

            SendToAll(new DataAnnounce { iep = p.iep, isPeer = true });
            ThreadPool.QueueUserWorkItem(new WaitCallback(delegate { p.ReceiveData(); }));

            return p;
        }




        /// <summary>
        /// Connect to peer with specified IEP
        /// </summary>
        /// <param name="iep">IEP to connect to</param>
        /// <returns></returns>
        public bool Connect(IPEndPoint iep)
        {
            Boolean connected = false;
            TcpClient tc = new TcpClient();

            try
            {
                tc.Connect(iep);
                connected = true;

                Peer p = addPeer(tc);
                p.SendHandShake();
            }
            catch (Exception e)
            {
                WriteNotice("Error during Connect() to " + iep.ToString() + " : " + e.Message);
            }

            return connected;
        }

        

        /// <summary>
        /// Send an UDP packet to broadcast
        /// </summary>
        public void ConnectUDP()
        {
            Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            sock.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Broadcast, 1);
            IPEndPoint iep = new IPEndPoint(IPAddress.Broadcast, Self.udpPort);

            Byte[] b = BitConverter.GetBytes(Self.tcpPort);
            sock.SendTo(b, iep);

            sock.Close();
        }

        #endregion


        #region Send messages related

        private void tb_enter_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (!String.IsNullOrWhiteSpace(tb_enter.Text))
                    HandleThatShit(tb_enter.Text);
            }
            else if (e.Key == Key.Tab)
            {
                Autocomplete(tb_enter.Text);
                e.Handled = true;
            }
        }


        /// <summary>
        /// Handle commands
        /// </summary>
        /// <param name="txt"></param>
        void HandleThatShit(String txt)
        {
            String[] args = txt.Split(' ');

            if (txt == "/clear")
            {
                tb_display.Clear();
                GetChanById(Self.currentChannel).history = "";
            }
            else if (txt == "/clearall")
            {
                tb_display.Clear();

                foreach (Chan c in Self.chans) c.history = "";
            }
            else if (txt.StartsWith("/connect"))
            {
                if (args.Length > 1)
                {
                    Connect(Peer.IPEndPointFromString(args[1]));
                }
                else
                    ConnectUDP();
            }
            else if (txt.StartsWith("/ignore "))
            {
                if (args.Length > 1)
                {
                    Peer p = GetPeerByPseudo(args[1]);
                    if (p != null)
                        p.isIgnored = !p.isIgnored;
                }
            }
            else if (txt.StartsWith("/nick "))
            {
                Self.pseudo = args[1];

                SendToAll(new DataChangeNick { newPseudo = Self.pseudo });
            }
            else if (txt == "/close")
            {
                if (Self.currentChannel != Guid.Empty.ToString())
                {
                    Chan c = GetChanById(Self.currentChannel);
                    c.Leave();
                    c.Hide();
                }
            }
            else if (txt == "/exit")
            {
                Close();
            }
            else if (txt.StartsWith("/mp "))
            {
                int idxChan = GetChanIdxByName(args[1]);

                if (idxChan == -1)
                {
                    Peer p = GetPeerByPseudo(args[1]);

                    if (p != null)
                    {
                        Chan c = new Chan(args[1]);
                        c.isPrivate = true;
                        c.peers.Add(p);
                        c.addChan(true);
                        c.Show();

                        SelectedChan = c.id;
                        p.SendData(new DataChan { to = c.id, option = ChanOption.Create | ChanOption.Private });
                    }
                }
                else
                {
                    Self.chans[idxChan].Show();
                }

            }
            else if (txt.StartsWith("/join "))
            {
                if (args.Length > 1)
                {
                    Chan c = GetChanByName(args[1]);

                    if (c == null)
                    {
                        c = new Chan(args[1]);
                        c.addChan(true);
                        c.Join();

                        SelectedChan = c.id;
                        SendToAll(new DataChan { name = args[1], option = ChanOption.Create, to = c.id });
                    }
                    else
                    {
                        c.Join();
                        SelectedChan = c.id;
                    }
                }
            }
            else if (txt.StartsWith("/list "))
            {
                if (args[1] == "peers")
                {
                    foreach (Peer p in Self.peers)
                    {
                        WriteNotice(p.pseudo + " - " + p.iep + " - " + p.id + " - " + p.isAlive);
                    }
                }
                else if (args[1] == "chans")
                {
                    foreach (Chan c in Self.chans)
                    {
                        WriteNotice(c.name + " - " + c.id);
                    }
                }
                else if (args[1] == "files")
                {
                    foreach (sFile f in Self.files)
                    {
                        WriteNotice(f.name + "(" + f.StringSize() + ")" + " - " + f.hash);
                    }
                }
            }
            else if (txt.StartsWith("/file "))
            {
                if (args[1] == "send")
                {
                    if (File.Exists(Self.incomingFolder + args[2]))
                    {
                        Sendfile(Self.incomingFolder + args[2], Self.currentChannel);

                        RefreshFiles();
                    }
                }
                else if (args[1] == "accept")
                {
                    int idxFile = GetFileIndexByHash(args[2]);
                    if (idxFile == -1) idxFile = GetFileIndexByName(args[2]);

                    if (idxFile > -1)
                    {
                        Self.files[idxFile].etat = FileStatus.Accepted | FileStatus.Receive;

                        RefreshFiles();
                        SendTo(new DataFile { fileinfo = Self.files[idxFile] }, Self.currentChannel);
                    }
                }
                else if (args[1] == "cancel")
                {
                    int idxFile = GetFileIndexByHash(args[2]);
                    if (idxFile == -1) idxFile = GetFileIndexByName(args[2]);

                    if (idxFile > -1)
                    {
                        Self.files[idxFile].etat = FileStatus.Canceled | FileStatus.Receive;

                        RefreshFiles();
                        SendTo(new DataFile { fileinfo = Self.files[idxFile] }, Self.currentChannel);
                    }
                }
                else if (args[1] == "clear")
                {

                    for (int i = 0; i < Self.files.Count; i++)
                    {
                        if (Self.files[i].etat == FileStatus.Canceled || Self.files[i].etat == FileStatus.Finished)
                        {
                            Self.files.RemoveAt(i);
                            i--;
                        }
                    }
                    RefreshFiles();
                }
            }
            else if (txt == "/voice")
            {
                SwitchSound();
            }
            else if (txt == "/show peers")
            {
                TogglePeers();
            }
            else if (txt == "/show files")
            {
                ToggleFiles();
            }
            else if (txt == "/help")
            {
                WriteNotice("Commandes :");
                WriteNotice("/clear : clear history on the current chan=");
                WriteNotice("/clearall : clear all histories");
                WriteNotice("/connect [<IP:port>] : connect broadcast or to a specified IP");
                WriteNotice("/ignore <pseudo> : ignore/unignore");
                WriteNotice("/close : close current chan");
                WriteNotice("/exit : exit ChaKeyz");
                WriteNotice("/nick <pseudo> : change nick");
                WriteNotice("/mp <pseudo> : MP someone");
                WriteNotice("/join <chan> : Join/create chan");
                WriteNotice("/list <peers,chans,files,nodes>");
                WriteNotice("/file <send,accept,cancel>");
                WriteNotice("/voice : enable/disable voice");
                WriteNotice("/show <peers,files> : show/hide peers or files panel");
            }
            else
            {
                SendTo(new DataMessage { msg = txt }, Self.currentChannel);

                WriteMessage(Self.pseudo, txt, Self.currentChannel);
            }
            tb_enter.Text = "";
        }


        /// <summary>
        /// Return time (short format)
        /// </summary>
        /// <returns></returns>
        public String GetTime()
        {
            return DateTime.Now.ToShortTimeString();
        }



        public void WriteMessage(String pseudo, String txt, String idChan, MessageType mt = MessageType.Channel)
        {
            WriteText(Environment.NewLine + "[" + GetTime() + "] " + pseudo + " : " + txt, idChan, MessageType.Message | mt);
        }

        public void WriteNotice(String txt, String idChan = "", MessageType mt = MessageType.Current)
        {
            WriteText(Environment.NewLine + "[" + GetTime() + "] NOTICE : " + txt, idChan, MessageType.Notice | mt);
        }


        public void WriteText(String txt, String idChan, MessageType mt)
        {

            if (mt.HasFlag(MessageType.Current))
                WriteRaw(txt);

            if (mt.HasFlag(MessageType.Main))
            {
                if (Self.currentChannel == Guid.Empty.ToString())
                    WriteRaw(txt);
                else
                {
                    GetChanById(Guid.Empty.ToString()).history += txt;
                    GetChanById(Guid.Empty.ToString()).newMessages = true;
                }
            }

            if (mt.HasFlag(MessageType.Global))
            {
                foreach (Chan c in Self.chans)
                {
                    if (c.id == Self.currentChannel)
                        WriteRaw(txt);
                    else
                    {
                        c.history += txt;
                        c.newMessages = true;
                    }
                }
            }
            else if (mt.HasFlag(MessageType.Channel))
            {
                if (Self.currentChannel == idChan)
                    WriteRaw(txt);
                else
                {
                    Chan c = GetChanById(idChan);
                    c.history += txt;
                    c.newMessages = true;
                }
                
            }

            RefreshChans();
        }


        public void WriteRaw(String txt)
        {
            Dispatcher.Invoke(() =>
            {
                tb_display.Text += txt;
                tb_display.ScrollToEnd();
            });
        }
        


        public void SendToAll(Data data)
        {
            SendToPeers(data);
        }


        public void SendTo(Data data, String to)
        {
            data.from = Self.id;
            data.to = to;
            Chan c = (Chan)GetChanById(to);

            if (c != null)
            {
                foreach (Peer p in c.peers) p.SendData(data);
            }
            else
            {
                Peer p = GetPeerById(to);

                if (p != null)
                {
                    if (p.connected) p.SendData(data);
                }
                    
            }
        }


        public void SendToPeers(Data data)
        {
            data.from = Self.id;
            foreach (Peer p in Self.peers)
            {
                if (p.connected) p.SendData(data);
            }

        }


        void s_DataReceived(byte[] buffer)
        {
            foreach (Peer p in GetChanById(Self.currentChannel).peers)
            {
                p.SendData(new DataVoice { buffer = buffer });
            }
        }


        #endregion



        #region GetShitBy functions

        public Peer GetPeerById(String id)
        {
            return Self.peers.Find(x => x.id == id);
        }

        public Peer GetPeerByPseudo(String pseudo)
        {
            return Self.peers.Find(x => x.pseudo == pseudo);
        }

        public Chan GetChanById(String id)
        {
            return (Chan)Self.chans.Find(x => x.id == id);
        }

        public Chan GetChanByName(String name)
        {
            return (Chan)Self.chans.Find(x => x.name == name);
        }

        public int GetChanIdxByName(String name)
        {
            return Self.chans.FindIndex(x => x.name == name);
        }

        public int GetTabChanById(String id)
        {
            int idx = -1;
            bool found = false;

            while (!found && idx < tc_chans.Items.Count - 1)
            {
                found = (((Chan)tc_chans.Items[++idx]).id == id);
            }

            return (found) ? idx : -1;
        }


        public String SelectedChan
        {
            get { return ((Chan)tc_chans.SelectedItem).id; }
            set { tc_chans.SelectedIndex = GetTabChanById(value); Self.currentChannel = value; }
        }

        public sFile GetFileByHash(String hash)
        {
            return Self.files.Find(x => x.hash == hash);
        }

        public int GetFileIndexByHash(String hash)
        {
            return Self.files.FindIndex(x => x.hash == hash);
        }


        public int GetFileIndexByName(String name)
        {
            return Self.files.FindIndex(x => x.name == name);
        }


        #endregion



        public PeerItem[] GetPeersItem()
        {
            PeerItem[] peers = new PeerItem[Self.peers.Count];

            for (int i = 0; i < peers.Length; i++) peers[i] = Self.peers[i].GetItem();

            return peers;
        }
        
        public ChanItem[] GetChansItem()
        {
            ChanItem[] chans = new ChanItem[Self.chans.Count];

            for (int i = 0; i < chans.Length; i++) chans[i] = Self.chans[i].GetItem();

            return chans;
        }


        #region UI related

        private void tc_chans_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            String currentChatHistory = tb_display.Text;

            Chan previouschan = GetChanById(Self.currentChannel);
            if (tc_chans.SelectedIndex == -1) tc_chans.SelectedIndex = 0;

            Chan newchan = (Chan)tc_chans.SelectedItem;
            //Chan newchan = Self.chans[tc_chans.SelectedIndex];

            previouschan.history = currentChatHistory;

            tb_display.Clear();
            tb_display.Text = newchan.history;
            tb_display.ScrollToEnd();

            newchan.newMessages = false;
            Self.currentChannel = newchan.id;
            RefreshPeers();
            RefreshChans();
        }




        void SwitchSound()
        {
            Self.snd.enabled = !Self.snd.enabled;

            if (Self.snd.enabled)
            {
                Self.snd.StartRecord();
                Self.snd.DataReceived += s_DataReceived;
            }
            else
            {
                Self.snd.DataReceived -= s_DataReceived;
                Self.snd.StopRecord();
            }
        }


        public void RefreshChans()
        {
            Dispatcher.Invoke(() =>
            {
                tc_chans.ItemsSource = Self.chans.Where(x => x.opened == true);
                tc_chans.Items.Refresh();
            });
        }

        public void RefreshFiles()
        {
            Dispatcher.Invoke(() =>
            {
                lb_files.ItemsSource = Self.files.Where(x => x.to == Self.currentChannel);
                lb_files.Items.Refresh();
            });
        }

        public void RefreshPeers()
        {
            Dispatcher.Invoke(() =>
            {
                lb_peers.ItemsSource = GetChanById(Self.currentChannel).peers;
                lb_peers.Items.Refresh();
            });
        }

        public Boolean showPeers = true;
        public Boolean showFiles = true;

        public void TogglePeers()
        {
            if (showPeers)
            {
                lb_peers.Visibility = System.Windows.Visibility.Collapsed;
                this.Width -= lb_peers.Width;
            }
            else
            {
                lb_peers.Visibility = System.Windows.Visibility.Visible;
                this.Width += lb_peers.Width;
            }

            showPeers = !showPeers;
        }

        public void ToggleFiles()
        {
            if (showFiles)
            {
                lb_files.Visibility = System.Windows.Visibility.Collapsed;
                this.Height -= lb_files.Height;
            }
            else
            {
                lb_files.Visibility = System.Windows.Visibility.Visible;
                this.Height += lb_files.Height;
            }

            showFiles = !showFiles;
        }

        #endregion


        int optionNum = 0;
        String lastStrSearch = "";

        private void Autocomplete(String txt)
        {
            String strSearch = "", beforeStr = "";

            int idx = txt.LastIndexOf(' ');

            if (idx != -1)
            {
                beforeStr = txt.Substring(0, idx + 1);
                strSearch = txt.Substring(idx + 1);
            }
            else
                strSearch = txt;


            if (!strSearch.StartsWith(lastStrSearch))
            {
                optionNum = 0;
            }
            else
                strSearch = lastStrSearch;


            //autocomplete files
            if (beforeStr == "/file send ")
            {
                String[] tabFile = Directory.GetFiles(Self.incomingFolder, strSearch + "*");

                for (int i = 0, n = tabFile.Length; i < n; i++)
                {
                    tabFile[i] = Path.GetFileName(tabFile[i]);
                }

                if (tabFile.Length == 1)
                {
                    tb_enter.Text = beforeStr + tabFile[0];
                    tb_enter.Select(tb_enter.Text.Length, 0);
                }
                else if (tabFile.Length > 1)
                {
                    tb_enter.Text = beforeStr + tabFile[optionNum];
                    tb_enter.Select(beforeStr.Length, tabFile[optionNum].Length);

                    lastStrSearch = strSearch;
                    if (++optionNum == tabFile.Length) optionNum = 0;
                }
            
            }
            else if (beforeStr == "/file accept " || beforeStr == "/file cancel ")
            {
                IEnumerable<sFile> files = Self.files.Where(x => x.name.StartsWith(strSearch));
                sFile[] tabFile = files.ToArray();

                if (tabFile.Length == 1)
                {
                    tb_enter.Text = beforeStr + tabFile[0].name;
                    tb_enter.Select(tb_enter.Text.Length, 0);
                }
                else if (tabFile.Length > 1)
                {
                    tb_enter.Text = beforeStr + tabFile[optionNum].name;
                    tb_enter.Select(beforeStr.Length, tabFile[optionNum].name.Length);

                    lastStrSearch = strSearch;
                    if (++optionNum == tabFile.Length) optionNum = 0;
                }
            }
            else if (beforeStr == "/join ")
            {
                List<String> tabChan = new List<String>();

                foreach (Chan c in Self.chans)
                {
                    if (c.name.StartsWith(strSearch, StringComparison.CurrentCultureIgnoreCase))
                        tabChan.Add(c.name);
                }

                if (tabChan.Count == 1)
                {
                    tb_enter.Text = beforeStr + tabChan[0];
                    tb_enter.Select(tb_enter.Text.Length, 0);
                }
                else if (tabChan.Count > 1)
                {
                    tb_enter.Text = beforeStr + tabChan[optionNum];
                    tb_enter.Select(beforeStr.Length, tabChan[optionNum].Length);

                    lastStrSearch = strSearch;
                    if (++optionNum == tabChan.Count) optionNum = 0;
                }
            }
            else //peers
            {
                List<String> tabPseudo = new List<String>();

                foreach (Peer p in Self.peers)
                {
                    if (p.isAlive && p.pseudo.StartsWith(strSearch, StringComparison.CurrentCultureIgnoreCase))
                        tabPseudo.Add(p.pseudo);
                }

                if (tabPseudo.Count == 1)
                {
                    tb_enter.Text = beforeStr + tabPseudo[0];
                    tb_enter.Select(tb_enter.Text.Length, 0);
                }
                else if (tabPseudo.Count > 1)
                {
                    tb_enter.Text = beforeStr + tabPseudo[optionNum];
                    tb_enter.Select(beforeStr.Length, tabPseudo[optionNum].Length);

                    lastStrSearch = strSearch;
                    if (++optionNum == tabPseudo.Count) optionNum = 0;
                }
            }
        }




        public void Sendfile(sFile f, String to)
        {
            f.etat = FileStatus.Waiting | FileStatus.Send;
            f.to = to;
            f.from = Self.id;
            Self.files.Add(f);

            SendTo(new DataFile { fileinfo = f }, to);
        }


        public void Sendfile(String path, String to)
        {
            sFile f = new sFile(path);
            Sendfile(f, to);
        }

        /// <summary>
        /// Vérifie si l'IP fait partie des IP locales
        /// </summary>
        /// <param name="ip">L'IP a vérifier</param>
        /// <returns></returns>
        public bool IsLocalAddress(IPAddress ip)
        {
            bool isLocalAddress = false;

            if (ip.Equals(IPAddress.Loopback) || ip.Equals(IPAddress.IPv6Loopback))
                isLocalAddress = true;
            else
            {
                IPAddress[] tab_ip = Dns.GetHostEntry(Environment.MachineName).AddressList;

                for (int idx = 0, n = tab_ip.Length; idx < n && !isLocalAddress; idx++)
                {
                    if (ip.Equals(tab_ip[idx]))
                        isLocalAddress = true;
                }
            }

            return isLocalAddress;
        }


        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            SendToAll(new DataDisconnect { });
            listeningTCP = listeningUDP = false;
            Dispatcher.InvokeShutdown();

            if (t_listenerUDP != null) t_listenerUDP.Abort();
            if (t_listenerTCP != null) t_listenerTCP.Abort();

            while (Self.peers.Count > 0) Self.peers[Self.peers.Count - 1].Kill();

            if (doneEvents.Count > 0) WaitHandle.WaitAll(doneEvents.ToArray());
        }

    }
}