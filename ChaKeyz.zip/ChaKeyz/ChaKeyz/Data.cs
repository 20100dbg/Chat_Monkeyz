﻿using System;
using System.Net;
using System.Security.Cryptography;
using System.IO;
using System.Collections.Generic;

namespace ChaKeyz
{

    public enum DataType { Announce, Handshake, Key, Message, Disconnect, ChangeNick, File, Voice, Chan, Sync };

    [Serializable]
    public class Data
    {
        public DataType type;
        public String from;
        public String to;

        public Data Clone()
        {
            return (Data)MemberwiseClone();
        }

        public override String ToString()
        {
            return type.ToString();
        }
    }


    [Serializable]
    public class DataAnnounce : Data
    {
        public IPEndPoint iep;
        public Boolean isPeer;
        public Boolean isNode;

        public DataAnnounce() { base.type = DataType.Announce; }

        public override String ToString()
        {
            return iep.ToString();
        }

    }

    [Serializable]
    public class DataHandshake : Data
    {
        public String id;
        public String pseudo;
        public Boolean imNode;
        public Boolean imPeer;

        public DataHandshake() { base.type = DataType.Handshake; }

        public override String ToString()
        {
            return pseudo;
        }
    }

    [Serializable]
    public class DataKey : Data
    {
        public String rsaPublicKey;
        public String aesKey;
        public String IV;
        public Int16 step;

        public DataKey() { base.type = DataType.Key; }

        public override String ToString()
        {
            return step + " : " + rsaPublicKey + " - " + aesKey + " - " + IV;
        }
    }


    [Serializable]
    public class DataMessage : Data
    {
        public String msg;

        public DataMessage() { base.type = DataType.Message; }

        public override String ToString()
        {
            return msg;
        }
    }

    [Serializable]
    public class DataDisconnect : Data
    {
        public DataDisconnect() { base.type = DataType.Disconnect; }
    }

    [Serializable]
    public class DataChangeNick : Data
    {
        public String newPseudo;

        public DataChangeNick() { base.type = DataType.ChangeNick; }

        public override String ToString()
        {
            return newPseudo;
        }
    }


    [Serializable]
    public class DataFile : Data
    {
        public sFile fileinfo;
        public Byte[] data = new Byte[Self.buffersize];
        public Int64 position;

        public DataFile() { base.type = DataType.File; }


        public override String ToString()
        {
            return fileinfo.ToString();
        }
    }

    

    [Serializable]
    public class DataVoice : Data
    {
        public Byte[] buffer;

        public DataVoice() { base.type = DataType.Voice; }

    }


    [Flags]
    public enum ChanOption { Create = 1, Join = 2, Leave = 4, Private = 8, Protected = 16 };


    [Serializable]
    public class DataChan : Data
    {
        public ChanOption option;
        public String name;
        
        public DataChan() { base.type = DataType.Chan; }

    }

    [Serializable]
    public class PeerItem
    {
        public String id;
        public String pseudo;
        public IPEndPoint iep;
    }

    [Serializable]
    public class ChanItem
    {
        public String id;
        public String name;
        public Boolean opened;
    }


    [Serializable]
    public class DataSync : Data
    {
        public PeerItem[] peers;
        public ChanItem[] chans;


        public DataSync() { base.type = DataType.Sync; }
    }



    //sending receiving with/without error
    [Flags]
    public enum FileStatus { Accepted = 1, Canceled = 2, InProgress = 4, Finished = 8, Waiting = 16, Send = 32, Receive = 64 };


    [Serializable]
    public class sFile
    {
        public String hash;
        public String path;
        public String name;
        public Int64 size;
        public FileStatus etat;

        public String from;
        public String to;

        String[] tabSize = { "o", "ko", "mo", "go", "to", "po" };


        public String Name { get { return name; } }
        public String Size { get { return StringSize(); } }
        public String Status { get { return (etat &= ~FileStatus.Send & ~FileStatus.Receive).ToString(); } }
        public String Direction
        {
            get
            {
                return "From " + ((from == Self.id) ? Self.pseudo : Self.win.GetPeerById(from).pseudo) +
                    " to " + ((to == Self.id) ? Self.pseudo : Self.win.GetChanById(to).name);
            }
        }

        public sFile(String path)
        {
            this.path = path;
            name = Path.GetFileName(path);
            size = new FileInfo(path).Length;
            etat = FileStatus.Waiting;
            hash = Hash(path);
        }

        public String StringSize()
        {
            Double s = size;
            int x = 0;

            while (s > 1024 && x < tabSize.Length - 1)
            {
                s /= 1024;
                x++;
            }

            return Math.Round(s, 2) + tabSize[x];
        }

        public static String Hash(String filename)
        {
            String hash;

            using (MD5 md5 = MD5.Create())
            {
                using (FileStream stream = File.OpenRead(filename))
                {
                    hash = BitConverter.ToString(md5.ComputeHash(stream)).Replace("-", "");
                }
            }

            return hash;
        }


        public override string ToString()
        {
            return name + " (" + StringSize() + ")";
        }

       /* 
        public override bool Equals(object obj)
        {
            return ((sFile)obj).hash == hash;
        }
        */

        public override int GetHashCode()
        {
            return hash.GetHashCode();
        }

    }
}